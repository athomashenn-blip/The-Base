Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Robe_lighting@Robin_iBolt@Mode_1_-_Standard_16_bit@2025-04-16%20%20Safety%20channel%20sets%20name%20revision.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

