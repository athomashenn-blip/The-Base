Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Robe_lighting@Robin_iPainte@Mode_1_-_Standard_16_bit@2024-10-17%20%20Updated%20from%20GDTF%20release.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

