Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Robe_lighting@Robin_T3_Profile@Mode_3_-_RGBALG@2026-01-28%20Converted%20from%20GDTF%20share.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

