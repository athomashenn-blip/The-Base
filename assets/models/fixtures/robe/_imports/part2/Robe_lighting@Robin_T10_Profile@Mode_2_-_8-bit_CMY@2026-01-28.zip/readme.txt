Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Robe_lighting@Robin_T10_Profile@Mode_2_-_8-bit_CMY@2026-01-28.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

